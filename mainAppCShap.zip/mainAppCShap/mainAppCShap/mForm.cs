﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace mainAppCShap
{
    public partial class mForms : Form
    {
        public mForms()
        {
            InitializeComponent();

            String[] linez = new String[100];

            StreamReader mRead = new StreamReader("../../DataF/cntz.txt");
            String myLine = "";
            String name1 = "";
            String surname1 = "";
            String email1 = "";
            String phone1 = "";
            String imageM = "";
            String abt1 = "";

            int i = 0;

            while(!mRead.EndOfStream)
            {
                linez[i] = mRead.ReadLine();

                name1 = linez[i].Substring(0, linez[i].IndexOf(","));
                linez[i] = linez[i].Remove(0, linez[i].IndexOf(",") + 1);

                surname1 = linez[i].Substring(0, linez[i].IndexOf(","));
                linez[i] = linez[i].Remove(0, linez[i].IndexOf(",") + 1);

                phone1 = linez[i].Substring(0, linez[i].IndexOf(","));
                linez[i] = linez[i].Remove(0, linez[i].IndexOf(",") + 1);

                email1 = linez[i].Substring(0, linez[i].IndexOf(","));
                linez[i] = linez[i].Remove(0, linez[i].IndexOf(",") + 1);

                imageM = linez[i].Substring(0, linez[i].IndexOf(","));
                linez[i] = linez[i].Remove(0, linez[i].IndexOf(",") + 1);

                abt1 = linez[i].Substring(0, linez[i].Length);
                linez[i] = linez[i].Remove(0, linez[i].Length);

                myLine = name1 + " ";
                myLine += surname1 + "  |  ";
                myLine += phone1 + "  |  ";
                myLine += email1;

                listBox1.Items.Add((i+1).ToString() + "." + " " + myLine);
                i++;
            }

            String t1 = "I'm bubbly, I'm so not an extrovert but If you don't ask then";

//            MessageBox.Show(t1.Length.ToString());

            cntL.Text = listBox1.Items.Count.ToString();

        }

        private void addC_Click(object sender, EventArgs e)
        {
            
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void addC_Click_1(object sender, EventArgs e)
        {
           tabControl1.SelectedIndex = 1;
        }

        private void cAdd_Click(object sender, EventArgs e)
        {

            StreamWriter mWrite = new StreamWriter("../../DataF/cntz.txt", true);

            String oneLine = "";
            String oneLine2 = "";
            

            oneLine = mName.Text + ",";
            oneLine += mSur.Text + ",";
            oneLine += mNum.Text + ",";
            oneLine += mEmail.Text + ",";
            oneLine += "images ";
            oneLine += mImage.Text;
            oneLine += ".png" + ",";
            oneLine += mAbout.Text;

            if (mImage.Text == "(2)" || mImage.Text == "(3)" || mImage.Text == "(6)" ||
                mImage.Text == "(7)" || mImage.Text == "(8)" || mImage.Text == "(9)" || mImage.Text == "(10)")
            {
            mWrite.WriteLine(oneLine);

            MessageBox.Show(oneLine);

            mWrite.Close();

            oneLine2 = mName.Text + " ";
            oneLine2 += mSur.Text + " | ";
            oneLine2 += mNum.Text + " | ";
            oneLine2 += mEmail.Text;
            oneLine2 += "\n";

            listBox1.Items.Add((listBox1.Items.Count + 1).ToString() + "." + " " + oneLine2);
         
            tabControl1.SelectedIndex = 0;
            cntL.Text = listBox1.Items.Count.ToString();

        } else {

                MessageBox.Show("Please Enter A valid Image Name!" + "\n" + "You can either enter : \n" +
                    "     (2)" + "\n or " + "(3)" + "\n or " + "(6)" + "\n or " + "(7)" + "\n or " + "(8)" + "\n or " + "(9)"
                    + "\n or " + "(10)" + "\n as the Image Names");

                mWrite.Close();

            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            tabControl1.SelectedIndex = 2;

           // String oneLine2 = "";
            String path = "../../wImages/";
            String name1 = "";
            String surname1 = "";
            String email1 = "";
            String phone1 = "";
            String imageM = "";
            String abt1 = "";
            String adaBt = "";

            String[] linez = new String[listBox1.Items.Count];
            String myLine = "";
            String myLine2 = "";
            String abtSort = "";

            StreamReader mRead = new StreamReader("../../DataF/cntz.txt");
            int i = 0;

            while(!mRead.EndOfStream)
            {
                linez[i] = mRead.ReadLine();

                i++;

            }
            mRead.Close();
            if (i > 0)
            {
                //pictureBox1.Load("../../DataF/images.png");
                name1 = linez[listBox1.SelectedIndex].Substring(0, linez[listBox1.SelectedIndex].IndexOf(","));
                linez[listBox1.SelectedIndex] = linez[listBox1.SelectedIndex].Remove(0, linez[listBox1.SelectedIndex].IndexOf(",") + 1);

                surname1 = linez[listBox1.SelectedIndex].Substring(0, linez[listBox1.SelectedIndex].IndexOf(","));
                linez[listBox1.SelectedIndex] = linez[listBox1.SelectedIndex].Remove(0, linez[listBox1.SelectedIndex].IndexOf(",") + 1);

                phone1 = linez[listBox1.SelectedIndex].Substring(0, linez[listBox1.SelectedIndex].IndexOf(","));
                linez[listBox1.SelectedIndex] = linez[listBox1.SelectedIndex].Remove(0, linez[listBox1.SelectedIndex].IndexOf(",") + 1);

                email1 = linez[listBox1.SelectedIndex].Substring(0, linez[listBox1.SelectedIndex].IndexOf(","));
                linez[listBox1.SelectedIndex] = linez[listBox1.SelectedIndex].Remove(0, linez[listBox1.SelectedIndex].IndexOf(",") + 1);

                imageM = linez[listBox1.SelectedIndex].Substring(0, linez[listBox1.SelectedIndex].IndexOf(","));
                linez[listBox1.SelectedIndex] = linez[listBox1.SelectedIndex].Remove(0, linez[listBox1.SelectedIndex].IndexOf(",") + 1);

                abt1 = linez[listBox1.SelectedIndex].Substring(0, linez[listBox1.SelectedIndex].Length);
                linez[listBox1.SelectedIndex] = linez[listBox1.SelectedIndex].Remove(0, linez[listBox1.SelectedIndex].Length);

                adaBt = abt1;
                

                while (abt1.Length >= 61)
                {
                    abtSort += abt1.Substring(0, 61) + "\n";
                    abt1 = abt1.Remove(0,61);
                }
                    //abtSort += abt1;
                if (abt1.Length < 61)
                {
                    abtSort += abt1;
                }

                pictureBox1.Load(path + imageM);

                nam.Text = name1;
                sur1.Text = surname1;
                about1.Text = abtSort;

                myLine = name1 + " ";
                myLine += surname1 + " | ";
                myLine += phone1 + " | ";
                myLine += email1;

                linkLabel1.Text = myLine;

                //MessageBox.Show(myLine);
            }
        }

        private void nam_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
                
   
        }

        private void visit_Click(object sender, EventArgs e)
        {

        }
    }
}
