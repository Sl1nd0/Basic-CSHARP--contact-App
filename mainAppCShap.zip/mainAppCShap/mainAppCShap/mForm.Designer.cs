﻿namespace mainAppCShap
{
    partial class mForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.addC = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.mImage = new System.Windows.Forms.TextBox();
            this.mAbout = new System.Windows.Forms.TextBox();
            this.Name = new System.Windows.Forms.Label();
            this.Sur = new System.Windows.Forms.Label();
            this.mName = new System.Windows.Forms.TextBox();
            this.mSur = new System.Windows.Forms.TextBox();
            this.cAdd = new System.Windows.Forms.Button();
            this.about = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.Number = new System.Windows.Forms.Label();
            this.mEmail = new System.Windows.Forms.TextBox();
            this.mNum = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.request = new System.Windows.Forms.Button();
            this.visit = new System.Windows.Forms.Button();
            this.about1 = new System.Windows.Forms.Label();
            this.sur1 = new System.Windows.Forms.Label();
            this.nam = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cntL = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(551, 339);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.cntL);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.addC);
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(543, 313);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // addC
            // 
            this.addC.Location = new System.Drawing.Point(8, 263);
            this.addC.Name = "addC";
            this.addC.Size = new System.Drawing.Size(75, 23);
            this.addC.TabIndex = 1;
            this.addC.Text = "Add Contact";
            this.addC.UseVisualStyleBackColor = true;
            this.addC.Click += new System.EventHandler(this.addC_Click_1);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(8, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(490, 251);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.mImage);
            this.tabPage2.Controls.Add(this.mAbout);
            this.tabPage2.Controls.Add(this.Name);
            this.tabPage2.Controls.Add(this.Sur);
            this.tabPage2.Controls.Add(this.mName);
            this.tabPage2.Controls.Add(this.mSur);
            this.tabPage2.Controls.Add(this.cAdd);
            this.tabPage2.Controls.Add(this.about);
            this.tabPage2.Controls.Add(this.Email);
            this.tabPage2.Controls.Add(this.Number);
            this.tabPage2.Controls.Add(this.mEmail);
            this.tabPage2.Controls.Add(this.mNum);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(543, 313);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Image";
            // 
            // mImage
            // 
            this.mImage.Location = new System.Drawing.Point(113, 102);
            this.mImage.Name = "mImage";
            this.mImage.Size = new System.Drawing.Size(332, 20);
            this.mImage.TabIndex = 12;
            // 
            // mAbout
            // 
            this.mAbout.Location = new System.Drawing.Point(113, 221);
            this.mAbout.Name = "mAbout";
            this.mAbout.Size = new System.Drawing.Size(332, 20);
            this.mAbout.TabIndex = 11;
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(33, 24);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(35, 13);
            this.Name.TabIndex = 10;
            this.Name.Text = "Name";
            // 
            // Sur
            // 
            this.Sur.AutoSize = true;
            this.Sur.Location = new System.Drawing.Point(33, 68);
            this.Sur.Name = "Sur";
            this.Sur.Size = new System.Drawing.Size(23, 13);
            this.Sur.TabIndex = 9;
            this.Sur.Text = "Sur";
            // 
            // mName
            // 
            this.mName.Location = new System.Drawing.Point(113, 21);
            this.mName.Name = "mName";
            this.mName.Size = new System.Drawing.Size(332, 20);
            this.mName.TabIndex = 8;
            // 
            // mSur
            // 
            this.mSur.Location = new System.Drawing.Point(113, 65);
            this.mSur.Name = "mSur";
            this.mSur.Size = new System.Drawing.Size(332, 20);
            this.mSur.TabIndex = 7;
            // 
            // cAdd
            // 
            this.cAdd.Location = new System.Drawing.Point(113, 270);
            this.cAdd.Name = "cAdd";
            this.cAdd.Size = new System.Drawing.Size(75, 23);
            this.cAdd.TabIndex = 6;
            this.cAdd.Text = "Add";
            this.cAdd.UseVisualStyleBackColor = true;
            this.cAdd.Click += new System.EventHandler(this.cAdd_Click);
            // 
            // about
            // 
            this.about.AutoSize = true;
            this.about.Location = new System.Drawing.Point(33, 224);
            this.about.Name = "about";
            this.about.Size = new System.Drawing.Size(35, 13);
            this.about.TabIndex = 5;
            this.about.Text = "About";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(33, 181);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(32, 13);
            this.Email.TabIndex = 3;
            this.Email.Text = "Email";
            // 
            // Number
            // 
            this.Number.AutoSize = true;
            this.Number.Location = new System.Drawing.Point(33, 148);
            this.Number.Name = "Number";
            this.Number.Size = new System.Drawing.Size(44, 13);
            this.Number.TabIndex = 2;
            this.Number.Text = "Number";
            // 
            // mEmail
            // 
            this.mEmail.Location = new System.Drawing.Point(113, 178);
            this.mEmail.Name = "mEmail";
            this.mEmail.Size = new System.Drawing.Size(332, 20);
            this.mEmail.TabIndex = 1;
            // 
            // mNum
            // 
            this.mNum.Location = new System.Drawing.Point(113, 141);
            this.mNum.Name = "mNum";
            this.mNum.Size = new System.Drawing.Size(332, 20);
            this.mNum.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.linkLabel1);
            this.tabPage3.Controls.Add(this.pictureBox1);
            this.tabPage3.Controls.Add(this.request);
            this.tabPage3.Controls.Add(this.visit);
            this.tabPage3.Controls.Add(this.about1);
            this.tabPage3.Controls.Add(this.sur1);
            this.tabPage3.Controls.Add(this.nam);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(543, 313);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(206, 167);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(55, 13);
            this.linkLabel1.TabIndex = 6;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "linkLabel1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(22, 39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 177);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // request
            // 
            this.request.Location = new System.Drawing.Point(326, 193);
            this.request.Name = "request";
            this.request.Size = new System.Drawing.Size(75, 23);
            this.request.TabIndex = 4;
            this.request.Text = "Request CV";
            this.request.UseVisualStyleBackColor = true;
            // 
            // visit
            // 
            this.visit.Location = new System.Drawing.Point(209, 193);
            this.visit.Name = "visit";
            this.visit.Size = new System.Drawing.Size(93, 23);
            this.visit.TabIndex = 3;
            this.visit.Text = "Visit Website";
            this.visit.UseVisualStyleBackColor = true;
            this.visit.Click += new System.EventHandler(this.visit_Click);
            // 
            // about1
            // 
            this.about1.AutoSize = true;
            this.about1.Location = new System.Drawing.Point(208, 83);
            this.about1.Name = "about1";
            this.about1.Size = new System.Drawing.Size(35, 13);
            this.about1.TabIndex = 2;
            this.about1.Text = "About";
            // 
            // sur1
            // 
            this.sur1.AutoSize = true;
            this.sur1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sur1.Location = new System.Drawing.Point(376, 39);
            this.sur1.Name = "sur1";
            this.sur1.Size = new System.Drawing.Size(105, 25);
            this.sur1.TabIndex = 1;
            this.sur1.Text = "Surname";
            // 
            // nam
            // 
            this.nam.AutoSize = true;
            this.nam.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nam.Location = new System.Drawing.Point(206, 39);
            this.nam.Name = "nam";
            this.nam.Size = new System.Drawing.Size(72, 25);
            this.nam.TabIndex = 0;
            this.nam.Text = "Name";
            this.nam.Click += new System.EventHandler(this.nam_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(287, 270);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Total Contacts:";
            // 
            // cntL
            // 
            this.cntL.AutoSize = true;
            this.cntL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cntL.Location = new System.Drawing.Point(441, 270);
            this.cntL.Name = "cntL";
            this.cntL.Size = new System.Drawing.Size(57, 20);
            this.cntL.TabIndex = 3;
            this.cntL.Text = "label3";
            // 
            // mForms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 337);
            this.Controls.Add(this.tabControl1);
            //this.Name = "mForms";
            this.Text = "mForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button addC;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label Number;
        private System.Windows.Forms.TextBox mEmail;
        private System.Windows.Forms.TextBox mNum;
        private System.Windows.Forms.Button cAdd;
        private System.Windows.Forms.Label about;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Label Sur;
        private System.Windows.Forms.TextBox mName;
        private System.Windows.Forms.TextBox mSur;
        private System.Windows.Forms.TextBox mAbout;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button request;
        private System.Windows.Forms.Button visit;
        private System.Windows.Forms.Label about1;
        private System.Windows.Forms.Label sur1;
        private System.Windows.Forms.Label nam;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox mImage;
        private System.Windows.Forms.Label cntL;
        private System.Windows.Forms.Label label2;

    }
}

